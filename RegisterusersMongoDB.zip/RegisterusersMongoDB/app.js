const express = require("express");
const bodyParser = require("body-parser");
const mongoose = require("mongoose");

const app = express();
app.use(express.static("static"));
app.use(bodyParser.urlencoded({extended:true}));
app.set("view engine", "ejs");

//mongo
mongoose.connect("mongodb://localhost:27017/userDB", {useNewUrlParser:true, useUnifiedTopology: true});

const userSchema = {
  name: String,
  email: String,
  password: String
};

const User = mongoose.model("User", userSchema);
//

let users = [];

function registeredUser(email, password, callback) {
  User.findOne({email, password}, function(err, user) {
    callback(user)
  });
};

//
app.get("/", function(req,res){
  res.sendFile(__dirname + "/static/html/signup.html");
});

//register
app.post("/register", function(req, res) {
  const name = req.body.name;
  const email = req.body.email;
  const password = req.body.password;
  console.log(name, email, password);

  registeredUser(email, password, function(result) {
    if (result) return res.redirect("/")
    const usr = new User({
      name,
      email,
      password
    });

    usr.save((err, obj) => {
      res.redirect("/users");
    });
  });
});

//login
app.post("/login", function(req, res) {
  const email = req.body.email;
  const password = req.body.password;
  console.log(email, password);

  registeredUser(email, password, function(result) {
    result ? res.redirect("/users") : res.redirect("/");
  })
});

//user management system
app.get("/users", function(req, res){
  User.find({}, (err, users) => {
    res.render("users", {users});
  });
});
//
app.get("/edit", function(req, res){
  const id = req.query.user;
  User.findById(id, (err, userData) => {
    if (!userData) return res.redirect("/users");
    res.render("edit", {user: userData});
  });
});

app.post("/edit", function(req, res) {
  const id = req.body.id;
  const name = req.body.name;
  const email = req.body.email;
  const password = req.body.password;
console.log(id, name, email, password);
  registeredUser(email, password, function(result) {
    if (result) return res.redirect("/edit");
    User.updateOne({_id: id}, { $set: {
      name,
      email,
      password
    }}, function() {
      res.redirect("/users");
    });
  });
});
//
app.get("/remove", function(req, res) {
  let id = req.query.id;
  User.deleteOne({_id: id}, function(err, count) {
    res.redirect("/users");
  });
});


app.listen(process.env.PORT || 3000, function(){
  console.log("Server is running on port 3000");
});
console.log("privet");
